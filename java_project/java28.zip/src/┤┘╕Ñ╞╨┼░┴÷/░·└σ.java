package 다른패키지;

import 상속.Employee;

public class 과장 extends Employee{
	public void print() {
		System.out.println(name + " " + salary);
	}
}
