package 상속;

public class 사람 extends Object{
	//성질+동작
	//멤버변수
	String name;
	int age;
	
	//멤버메서드
	public void 먹다() {
		System.out.println("사람이 먹다.");
	}
}
