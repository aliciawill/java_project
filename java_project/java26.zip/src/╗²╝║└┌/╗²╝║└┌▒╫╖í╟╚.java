package 생성자;

import javax.swing.JFrame;

public class 생성자그래픽 {

	public static void main(String[] args) {
//		JFrame f = new JFrame("나의 그래픽 창");
		JFrame f = new JFrame();
		f.setTitle("나의 그래픽 창2");
		
		f.setSize(500, 500);
		f.setVisible(true);

	}

}
