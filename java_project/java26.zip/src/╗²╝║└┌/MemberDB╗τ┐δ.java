package 생성자;

public class MemberDB사용 {

	public static void main(String[] args) throws Exception {
//		CRUD구현
		//create기능을 사용하고 싶음.
		MemberDB db = new MemberDB();
		MemberDB db2 = new MemberDB();
		MemberDB db3 = new MemberDB();
//		MemberVO bag = new MemberVO();
//		db.create(bag);
//		db.delete("test");
//		db.read("test");
	}

}
